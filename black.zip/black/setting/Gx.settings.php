<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@info-appleid.org",
        "password" => "Admur04012000"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "noreply@info-appleid.org",
        "password" => "Admur04012000"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@info-appleid.org",
        "password" => "Admur04012000"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 1,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/tester.txt",
    "fromname"       => "Apple Service",
    "frommail"       => "noreply-summarysuspendupdatelive##randstring##noreply@supporte-services-verifcations.com",
    "subject"        => "Re : [New Statement Added] [ Alert Information ] Detected Your Apple Account was signed in to Google Chrome from a new device on ( 26 January 2020 ) [FWD]",
    "msgfile"        => "file/letter/VlY.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://hootsuite.com"],
];
