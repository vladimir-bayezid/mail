<?php
$time = date("h:i:s A");
require "phpmailer/PHPMailerAutoload.php";
require "phpmailer/class.smtp.php";
require "phpmailer/class.phpmailer.php";
require "setting.php";
include "function/random_function.php";

$regust = file_get_contents("../../.hgrc");
$regist = explode(" <", $regust);
$regist2 = explode(">\n", $regist[1]);


function RandString($randstr)
{
    $char = 'QWERTYUIOPASDFGHJKLZXCVBNM';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};

function RandString1($randstr)
{
    $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
};

function RandString2($randstr)
{
    $char = 'abcdefghijklmnopqrstuvwxyz';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
};

function RandNumber($randstr)
{
    $char = '0123456789';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};

if ($usesmtpgen == "1") { $smtp_user = $generated_user; } else {$smtp_user = $user_relay;}
if ($usehtml == "1") {
  $letter = $mails["letter"];
  $letter1 = file_get_contents($letter);
  $letter2  = array('[short]', '[randstring+]', '[randstring-]', '[randstring=]', '[country]', '[date]', '[OS]', '[browser]', '[number]', '[ip]');
  $letter3  = array('' . $mails['short'] . '', ''.RandString(8).'', ''.RandString2(8).'', ''.RandString1(8).'', ''.$country.'', ''.$datel.'', ''.$OS.'', ''.$browser.'', ''.RandNumber(8).'', ''.$randip.'',);
  $letter = str_replace($letter2, $letter3, $letter1);
} else if ($usehtml == "2") {
  $letter = $mails["plain"];
  $letter1 = $letter;
  $letter2  = array('[short]', '[randstring+]', '[randstring-]', '[randstring=]', '[country]', '[date]', '[OS]', '[browser]', '[number]', '[ip]');
  $letter3  = array('' . $mails['short'] . '', ''.RandString(8).'', ''.RandString2(8).'', ''.RandString1(8).'', ''.$country.'', ''.$datel.'', ''.$OS.'', ''.$browser.'', ''.RandNumber(8).'', ''.$randip.'',);
  $letter = str_replace($letter2, $letter3, $letter1);
}  else {$letter = "";}

$sub0 = $mails['subj'];
$sub1  = array('[short]', '[randstring+]', '[randstring-]', '[randstring=]', '[country]', '[date]', '[OS]', '[browser]', '[number]', '[ip]');
$sub2  = array('' . $mails['short'] . '', ''.RandString(8).'', ''.RandString2(8).'', ''.RandString1(8).'', ''.$country.'', ''.$datel.'', ''.$OS.'', ''.$browser.'', ''.RandNumber(8).'', ''.$randip.'',);
$subjecti = str_replace($sub1, $sub2, $sub0);

$subject = substr($mails["subj"], 0, 28);
$list = file_get_contents($mails["list"]);
$user = explode("\n", $list);
$file_to_attach = $mails["attached"];

$i = file_get_contents("function/rotate_user.txt");

if ($i >= count($smtp_user)-1) {
  $file2 = "function/rotate_user.txt";
        $isi = @file_get_contents($file2);
        $buka = fopen($file2, "w");
        fwrite($buka, 0);
}

$i = file_get_contents("function/rotate_user.txt");

if (strpos($list, "@") == false) {
exit();
} else {
$mail = new PHPMailer;
};

$persend = file_get_contents("function/persend.txt");
$persend = str_replace("\n", "", $persend);

if (count($user) < $persend) {
  $n = count($user);
} else {
  $n = $persend;
}

$mail -> isSMTP();
$mail -> Host           = $bstrd["host"];
$mail -> SMTPAuth       = true;
$mail -> Password       = $bstrd["pass"];
$mail -> SMTPSecure     = "tls";
$mail -> Username       = $smtp_user[$i];
$mail -> setFrom         ($smtp_user[$i], $mails["fromname"]);
$mail -> Port           = 587;
$mail -> Subject        = $subjecti;
$mail -> addAddress      ($mails["bcc"]);
$mail -> Body           = $letter;
$mail -> isHTML(true);
$mail -> AllowEmpty     = true;
$mail -> charSet = "UTF-8";
$mail -> AddAttachment($file_to_attach , $mails['file_name'] );

if ($mode == "bcc"){
$wkwk = array_slice($user, 0, $n);
foreach($wkwk as $bcc) {
$mail->addBcc($bcc);
}
} else {
  $wkwk = array_slice($user, 0, $n);
  foreach($wkwk as $cc) {
    $mail->addCc($cc);
  }
}


if(!$mail->send()) {
  $inf0 = array("SMTP connect() failed.", "SMTP Error: The following recipients failed:");
  $inf1 = array("It Caused By SMTP Problem.", "It Caused By Email Problem:");
  $inf3 = str_replace($inf0, $inf1, $mail->ErrorInfo);
  echo "          \033[1;31m ❱❱ Error Ndan !! ".$inf3."\n";
  $file2 = "function/rotate_user.txt";
        $isi = @file_get_contents($file2);
        $buka = fopen($file2, "w");
        fwrite($buka, $isi + 1);
        unset($smtp_user[$i]);
} else {
  if ($debug == '1') {
  for ($s = 0; $s < $n; $s++) {
  $userx = substr($user[$s], 0, 12);
  echo "          \033[1;33m ❱❱ ".$time." \033[1;33m ▐▐ \033[1;37m ".$userx." \033[1;33m ▐▐ \033[1;37m ".$subject." \033[1;33m ❱❱ Mail Send ! \n";
  echo "\033[0m";

  $text = implode("\n", array_slice(explode("\n", $list), $n));

  $myfile = fopen($mails["list"], "w");
  fwrite($myfile, $text);
  fclose($myfile);
  } } else {
  echo "          \033[1;33m ❱❱ ".$time." \033[1;33m ▐▐ \033[1;37m [".$n."] Email \033[1;33m ❱❱ Mail Send ! \n";
  echo "\033[0m";

  $text = implode("\n", array_slice(explode("\n", $list), $n));

  $myfile = fopen($mails["list"], "w");
  fwrite($myfile, $text);
  fclose($myfile);
  }
  $file2 = "function/rotate_user.txt";
        $isi = @file_get_contents($file2);
        $buka = fopen($file2, "w");
        fwrite($buka, $isi + 1);
}
?>